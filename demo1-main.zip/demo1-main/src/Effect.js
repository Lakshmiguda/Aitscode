import React from 'react'

const Effect = () => {
  return (
    <div>Effect</div>
  )
}

export default Effect