import React from 'react'

const AddButton = () => {
  return (
    <div>
        <button>add to cart</button>
    </div>
  )
}

export default AddButton