import React from 'react'

const RemoveButton = () => {
  return (
    <div>
        <button>remove</button>
    </div>
  )
}

export default RemoveButton